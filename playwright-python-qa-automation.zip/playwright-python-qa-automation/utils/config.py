BASE_URL = "https://opensource-demo.orangehrmlive.com/"
VALID_USERNAME = "Admin"
VALID_PASSWORD = "admin123"
INVALID_PASSWORD = "wrongPassword123"
