# Playwright Python QA Automation Project

## Project Overview
A beginner-friendly QA automation framework built with Python, Playwright, and Pytest. The framework demonstrates UI automation, Page Object Model (POM), reusable fixtures, assertions, screenshots on failure, and HTML reporting.

## Application Under Test
OrangeHRM demo application:
https://opensource-demo.orangehrmlive.com/

## Tech Stack
- Python
- Playwright
- Pytest
- Pytest-HTML
- Page Object Model (POM)

## Test Scenarios
1. Valid login
2. Invalid login
3. Logout
4. Dashboard verification

## Project Structure
```text
playwright-python-qa-automation/
├── pages/
│   ├── login_page.py
│   └── dashboard_page.py
├── tests/
│   ├── test_login.py
│   └── test_logout.py
├── utils/
│   └── config.py
├── test_data/
│   └── credentials.json
├── screenshots/
├── reports/
├── conftest.py
├── pytest.ini
├── requirements.txt
└── README.md
```

## Setup

```bash
python -m venv venv
```

Windows:
```bash
venv\Scripts\activate
```

Install dependencies:
```bash
pip install -r requirements.txt
playwright install
```

Run all tests:
```bash
pytest
```

Run a specific test:
```bash
pytest tests/test_login.py -v
```

The HTML report is generated at:
`reports/report.html`

## Note
This is a personal QA automation practice project created to demonstrate Playwright + Python automation skills.
