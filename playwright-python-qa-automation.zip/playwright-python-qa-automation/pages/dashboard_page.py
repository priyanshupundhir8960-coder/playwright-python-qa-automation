from playwright.sync_api import Page, expect

class DashboardPage:
    def __init__(self, page: Page):
        self.page = page
        self.dashboard_heading = page.get_by_role("heading", name="Dashboard")

    def verify_dashboard(self):
        expect(self.dashboard_heading).to_be_visible()

    def logout(self):
        self.page.get_by_role("banner").get_by_text("Admin").click()
        self.page.get_by_text("Logout").click()
