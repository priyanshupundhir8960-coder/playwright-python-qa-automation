from pages.login_page import LoginPage
from pages.dashboard_page import DashboardPage
from utils.config import BASE_URL, VALID_USERNAME, VALID_PASSWORD

def test_logout(page):
    login = LoginPage(page)
    dashboard = DashboardPage(page)

    login.open(BASE_URL)
    login.login(VALID_USERNAME, VALID_PASSWORD)
    dashboard.verify_dashboard()
    dashboard.logout()
    page.get_by_placeholder("Username").wait_for()
