import json
from pages.login_page import LoginPage
from pages.dashboard_page import DashboardPage
from utils.config import BASE_URL

with open("test_data/credentials.json", encoding="utf-8") as file:
    DATA = json.load(file)

def test_valid_login(page):
    login = LoginPage(page)
    dashboard = DashboardPage(page)

    login.open(BASE_URL)
    login.login(DATA["valid"]["username"], DATA["valid"]["password"])
    dashboard.verify_dashboard()

def test_invalid_login(page):
    login = LoginPage(page)

    login.open(BASE_URL)
    login.login(DATA["invalid"]["username"], DATA["invalid"]["password"])
    login.verify_login_error()
